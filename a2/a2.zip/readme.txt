JobID: cp630-a2
Name: Vaibhav Thakur
ID: 235811400

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

A2

Q1 JMS and MDB for Statistics Application
Q1.1 [5/5/*] Message Queue MDB                       
Q1.2 [5/10/*] Message Topic MDB                       
Q1.3 [10/10/*] JMS clients                             
Q1.4 [10/10/*] JMS Clients within Servlet              
Q1.5 [10/10/*] JMS Clients within Session Beans        

Q2 Data persistence for Statistics Application
Q2.1 [10/10/*] DB Client and CRUD Operations           
Q2.2 [10/10/*] User Entity Bean                        
Q2.3 [10/10/*] Using User Entity Beans                 
Q2.4 [10/10/*] Model Entity Bean                       
Q2.5 [10/10/*] Using Model Entity Bean                 

Q3 Batch test
Q3.1 [5/5/*]  Create test output                     

Total: [100/100/*]


