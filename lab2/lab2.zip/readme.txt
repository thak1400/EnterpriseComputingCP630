JobID: cp630-lab2
Name: Vaibhav Thakur
ID: 235811400

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in each grading item in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Task_ID [self-evaluation/total/marker-evaluation] Description

Lab2

T1 Java Message Service (JMS)
T1.1 [3/3/*] Hand on helloworld-jms
T1.2 [3/3/*] JMS message queue programming
T1.3 [3/3/*] JMS topic programming

T2 Message Driven Bean (MDB)
T2.1 [3/3/*] WildFly message within Eclipse
T2.2 [3/3/*] Hand on helloworld-mdb project
T2.3 [3/3/*] ec-ejb MDB components
T2.4 [3/3/*] JMS web clients

T3 Database Connection
T3.1 [3/3/*] H2 database
T3.2 [3/3/*] MySQL database
T3.3 [3/3/*] JDBC client programming

T4 JPA and Hibernate
T4.1 [3/3/*] Hand on JPA example
T4.2 [3/3/*] Hand on ec-jpa project

T5 Entity Beans
T5.1 [3/3/*] Entity Beans with embedded H2
T5.2 [3/3/*] Entity Beans with standalone H2
T5.3 [4/4/*] Entity Beans with MySQL
T5.4 [4/4/*] ec-ejb entity components

Total: [50/50/*]
