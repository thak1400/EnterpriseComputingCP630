package ec.lab;

public interface Grade {
    public String getGrade(float grade);
    public String predictPass(float grade);
}