JobID: cp630-lab0
Name: Vaibhav Thakur
ID: 235811400
Email: thak1400@mylaurier.ca

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in each grading item in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Task_ID [self-evaluation/total/marker-evaluation] Description

Lab0

T1 Java JRE, JDK, Software Tools
T1.1 [2/2/*] Utility software
T1.2 [2/2/*] Java JRE and JDK
T1.3 [2/2/*] Apache Ant and Maven
T1.4 [2/2/*] Eclipse JEE

T2 Warm up Maven projects
T2.1 [2/2/*] ec-junit-log-mvn
T2.2 [2/2/*] Create Maven project
T2.3 [2/2/*] Maven project in Eclipse
T2.4 [2/2/*] ec-file-io-mvn
T2.5 [2/2/*] ec-stats
T2.6 [2/2/*] ec-regression

Total: [20/20/*]
