JobID: cp630-lab3
Name: Vaibhav Thakur
ID: 235811400

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in each grading item in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Task_ID [self-evaluation/total/marker-evaluation] Description

Lab3

T1 SOAP Web Services
T1.1 [3/3/*] Hand on helloworld-ws
T1.2 [6/6/*] ec-ws component
T1.3 [4/4/*] ec-ws client
T1.4 [4/4/*] Accessing SOAP WS by Servlet

T2 RESTful Web Services
T2.1 [3/3/*] Hand on helloworld-rs
T2.2 [6/6/*] ec-rs component

T3 Web Tier Components
T3.1 [6/6/*] Servlet Programming
T3.2 [5/5/*] Hand on JSP
T3.3 [5/5/*] Hand on JSF

T4 Client tier components
T4.1 [4/4/*] Java HTTP clients
T4.2 [4/4/*] JavaScript Client

Total: [50/50/*]
