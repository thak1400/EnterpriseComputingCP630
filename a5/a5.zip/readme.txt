JobID: cp630-a5
Name: Vaibhav Thakur
ID: 23811400

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

A5

Q1 Stats Computing by HDMR
Q1.1 [10/10/*] HDMR programming Stats model            
Q1.2 [10/10/*] Generating and Stats Model from HDFS    

Q2 Kmeans computing by HDMR
Q2.1 [10/10/*] HDMR programming for Kmeans model       
Q2.2 [10/10/*] Gnerating and using Kmeans model        

Q3 Spark Exploration and EC Integration
Q3.1 [5/5/*] Spark RDD                               
Q3.2 [5/5/*] Spark SQL                               
Q3.3 [5/5/*] Spark Machine Learning                  
Q3.4 [5/5/*] SparkX                                  
Q3.5 [10/10/*] Spark Models for EC                     

Total: [70/70/*]


